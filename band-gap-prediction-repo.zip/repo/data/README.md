# Data

Raw and processed data files are **not committed to this repository** — the raw pull alone is on the order of 60 MB, and Materials Project is a live, continuously updated database, so a committed CSV would silently go stale.

## How to reproduce the exact dataset used in this project

1. Get a free API key at https://next-gen.materialsproject.org/api
2. Run `notebooks/01_data_acquisition.ipynb` (or `python src/data_acquisition.py` with `MP_API_KEY` set as an environment variable)

This project's exact pull used:

| Parameter | Value |
|---|---|
| Query filter | `num_elements=(1, 9)` |
| Fields requested | `material_id, formula_pretty, formula_anonymous, chemsys, elements, nelements, composition, composition_reduced, band_gap, nsites, volume, density, density_atomic, symmetry, formation_energy_per_atom, energy_above_hull, is_stable, deprecated` |
| Records retrieved | 154,377 |
| Records after cleaning | 153,597 (see main README, "Dataset" section, for the exact cleaning steps and rationale) |

Because Materials Project is continuously updated, a re-pull today will not be byte-identical to the dataset used here. Each acquisition run writes a metadata JSON (`mp_bandgap_acquisition_metadata.json`) recording the exact retrieval date, package versions, and query parameters, for full provenance.

## Files this pipeline produces locally (not committed)

- `mp_bandgap_raw.csv` — raw pull
- `mp_bandgap_stage4_cleaned.csv` — after basic QA and outlier removal
- `mp_bandgap_features_composition_only.csv`, `mp_bandgap_features_composition_structure.csv` — engineered feature tables
- `mp_bandgap_stage6_split_ids.csv` — the exact train/test split used, by `material_id`
- `feature_dictionary.json`, `element_property_table.csv` — descriptor documentation
